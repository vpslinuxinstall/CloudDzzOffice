<?php
/*
 * @copyright   Leyun internet Technology(Shanghai)Co.,Ltd
 * @license     http://www.dzzoffice.com/licenses/license.txt
 * @package     DzzOffice
 * @link        http://www.dzzoffice.com
 * @author      zyx(zyx@dzz.cc)
 */

if(!defined('IN_DZZ')) {
	exit('Access Denied');
}

$lang = array
(
	'appname'=>'系统设置',
	'spaceSet'=>'空间设置',
	'loginSet'=>'登陆设置',
	'basicSet'=>'基本设置',
	'permGroupSet'=>'权限包设置',
	'spaceSet'=>'空间设置',
	'sitelogo' =>'平台LOGO',
	'default_app'=>'默认首页',
	'default_app_desc'=>'进入系统后的默认首页',
	'please_select_default_index'=>'请选择默认首页'
);


?>
