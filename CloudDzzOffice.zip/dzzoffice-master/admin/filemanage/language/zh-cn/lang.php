<?php
$lang = array (
	'appname' => '文件管理', 
	'rotation'=>'旋转',
    'checkednum'=>'<span>已选择<span class="ex-number"></span>项'
);
?>